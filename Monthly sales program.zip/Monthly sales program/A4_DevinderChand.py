# Name: [Devinder Chand]
# Assignment: [Assignment 4- PROG 12853 – Programming Foundations-Python]
# Program: [Computer Programming-PCPRG]

# [Monthly Sales program - a program that reads the sales for 12 months from a file and calculates the total yearly 
# sales as well as the average monthly sales. In addition, this program should let the user edit 
# the sales for any month.]

# This is the first part of the program which includes a one function for writing a file

def write_sales_data(filename, sales_data):
    with open(filename, 'w') as file:
        for month, sales in sales_data.items():
            file.write(f"{month} - {sales}\n")

# This is the second part of the program which includes a one function for reading  a file

def read_sales_data(filename):
    sales_data = {}
    with open(filename, 'r') as file:
        for line in file:
            month, sales = line.strip().split(':')
            sales_data[month] = int(sales)
    return sales_data

# This is the function of  the monthly sales and prints month and sales individually separted by hyphen
def view_monthly_sales(sales_data):
    for month, sales in sales_data.items():
        print(month,'-',sales)

# This is the function of  the yearly sales and prints monthly average sales and round it to 2 decimal places
def view_yearly_summary(sales_data):
    yearly_total = sum(sales_data.values())
    monthly_average = round(yearly_total / len(sales_data), 2)
    print(f"Yearly total: {yearly_total}")
    print(f"Monthly average: {monthly_average}")

# This is the function of the edit sales, demands first three letters of the month and if invalid prints invalid prints abbreviation and returns the function

def edit_sales(sales_data):
    month = input("Three-letter Month: ").capitalize()
    if month not in sales_data:
        print("Invalid month abbreviation.")
        return
    
    # This stement ask the user input for new sales amount for the respective amount 
    new_sales = int(input("Sales Amount: "))
    sales_data[month] = new_sales
    write_sales_data("monthly_sales.txt", sales_data)
    print(f"Sales amount for {month} was modified.")


# This is the main part of the program which includes while loop
# This part includes calling different functions 
def main():
    sales_data = read_sales_data("monthly_sales.txt")

    while True:
        # These statements prints the title and main menu of the program 
        print("\nMonthly Sales program\n")
        print("COMMAND MENU")
        print("monthly - View monthly sales")
        print("yearly - View yearly summary")
        print("edit - Edit sales for a month")
        print("exit - Exit program")

        # This line ask the user input make it lowercase alphabets
        command = input("\nCommand: ").lower()
        
        # These if , elif and else statements automatically return the value of the called functions respectively
        if command == 'monthly':
            view_monthly_sales(sales_data)
        elif command == 'yearly':
            view_yearly_summary(sales_data)
        elif command == 'edit':
            edit_sales(sales_data)
        elif command == 'exit':
            write_sales_data("monthly_sales.txt", sales_data)
            print("\nBye")
            break
        else:
            print("Invalid command. Please try again.")

# This is the last statment of the program which closes the main function
main()

