# Name: [Devinder Chand]
# Assignment: [Final Exam Part B - PROG 12853 – Programming Foundations-Python]
# Program: [Computer Programming-PCPRG]

# [Contact Manager - This is a great   program which used functions and files concept that a user can use to manage the name,
# primary email address and phone number for a contact.]


# Function to read contacts from the txt file
def read_contacts(file_name):
    contacts = []
    with open(file_name, 'r') as file:
        for line in file:
            name, email, phone = line.strip().split(',')  # Split the line into name, email, and phone
            contacts.append((name, email, phone))  # Append the contact tuple to the list
    return contacts

# Function to write contacts to the txt file
def write_contacts(file_name, contacts):
    with open(file_name, 'w') as file:
        for contact in contacts:
            file.write(','.join(contact) + '\n')  # Join contact fields with commas and write to file

# Main function
def main():
    file_name = "contacts.txt"
    contacts = read_contacts(file_name)  # Read contacts from the file

    print("Contact Manager\n")
    print("COMMAND MENU\n")
    print("list - Display all contacts")
    print("view - View a contact")
    print("add  - Add a contact")
    print("del  - Delete a contact")
    print("exit - Exit program")

    while True:
        command = input("\nCommand: ").strip().lower()

        if command == 'list':
            for i, contact in enumerate(contacts, start=1):
                print(f"Name: {contact[0]}, Email: {contact[1]}, Phone: {contact[2]}")
        elif command == 'view':
            number = int(input("Number: ")) - 1
            if number < 0 or number >= len(contacts):
                print("Invalid contact number.")
            else:
                contact = contacts[number]
                print(f"Name: {contact[0]}\nEmail: {contact[1]}\nPhone: {contact[2]}")
        elif command == 'add':
            name = input("Name: ")
            email = input("Email: ")
            phone = input("Phone: ")
            contacts.append((name, email, phone))  # Add the new contact
            write_contacts(file_name, contacts)  # Write contacts to the file
            print(f"{name} was added.")
        elif command == 'del':
            number = int(input("Number: ")) - 1
            if number < 0 or number >= len(contacts):
                print("Invalid contact number.")
            else:
                deleted_name = contacts[number][0]
                del contacts[number]  # Delete the contact
                write_contacts(file_name, contacts)  # Write contacts to the file
                print(f"{deleted_name} was deleted.")
        elif command == 'exit':
            print("Bye!")
            break
        else:
            print("Invalid command. Please enter a valid command.")

if __name__ == "__main__":
    main()
